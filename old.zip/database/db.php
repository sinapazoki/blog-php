<?php
	$database_username = 'rcacbeqq_blogusr';//user name
	$database_password = ')~yKmb=yA!v-';//password
	$pdo_conn = new PDO( 'mysql:host=localhost;dbname=rcacbeqq_blogdb', $database_username, $database_password );
?>
