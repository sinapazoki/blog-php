<?php
//database connection
($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost","rcacbeqq_blogusr",")~yKmb=yA!v-","rcacbeqq_blogdb"));  //host,user,password,database
?>
